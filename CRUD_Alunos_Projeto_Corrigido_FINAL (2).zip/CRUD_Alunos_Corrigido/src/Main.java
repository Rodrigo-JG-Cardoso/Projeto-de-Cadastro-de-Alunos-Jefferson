
import view.TelaCadastroAluno;

public class Main {
    public static void main(String[] args) {
        new TelaCadastroAluno();
    }
}
