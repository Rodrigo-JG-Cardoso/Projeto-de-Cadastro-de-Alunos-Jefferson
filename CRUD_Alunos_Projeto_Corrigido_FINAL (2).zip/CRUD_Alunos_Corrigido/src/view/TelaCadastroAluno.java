
package view;

import dao.AlunoDAO;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;

public class TelaCadastroAluno extends JFrame {

    String[] labels = {
        "Estuda atualmente na Etec?",
        "Estuda atualmente em outra Etec?",
        "Já estudou na Etec?",
        "Já concluiu o Ensino Médio?",
        "Em qual escola?",
        "Nome",
        "Nome Social",
        "CPF",
        "Gênero",
        "Data de nascimento",
        "Local de Nascimento",
        "Nacionalidade",
        "País de Origem",
        "Afrodescendente",
        "Escolaridade pública",
        "Filiação 1",
        "Filiação 2",
        "Responsável Legal",
        "Grau de Parentesco",
        "Habilitação",
        "Série/Módulo",
        "Período",
        "Rua/Avenida",
        "Complemento",
        "Apto",
        "Bloco",
        "Bairro",
        "Cidade",
        "CEP"
    };

    JComponent[] campos = new JComponent[29];

    public TelaCadastroAluno() {

        setTitle("Cadastro de Alunos");
        setSize(1000,700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel painel = new JPanel(new GridBagLayout());

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4,4,4,4);
        c.fill = GridBagConstraints.HORIZONTAL;

        for(int i=0;i<labels.length;i++) {

            c.gridx = 0;
            c.gridy = i;

            painel.add(new JLabel(labels[i] + ":"), c);

            if(i <= 3 || i == 13 || i == 14) {

                JComboBox<String> combo =
                new JComboBox<>(new String[]{"Sim","Não"});

                campos[i] = combo;

            } else {

                JTextField txt = new JTextField(25);

                if(i == 7 || i == 28) {
                    ((AbstractDocument)txt.getDocument())
                    .setDocumentFilter(new NumeroFilter());
                }

                campos[i] = txt;
            }

            c.gridx = 1;

            painel.add(campos[i], c);
        }

        JPanel botoes = new JPanel();

        JButton salvar = new JButton("Salvar");
        JButton listar = new JButton("Listar");
        JButton limpar = new JButton("Limpar");
        JButton sair = new JButton("Sair");

        botoes.add(salvar);
        botoes.add(listar);
        botoes.add(limpar);
        botoes.add(sair);

        c.gridx = 0;
        c.gridy = labels.length;
        c.gridwidth = 2;

        painel.add(botoes, c);

        salvar.addActionListener(e -> {

            String[] dados = new String[29];

            for(int i=0;i<campos.length;i++) {

                if(campos[i] instanceof JComboBox) {

                    dados[i] =
                    ((JComboBox<?>)campos[i]).getSelectedItem().toString();

                } else {

                    dados[i] =
                    ((JTextField)campos[i]).getText();
                }
            }

            new AlunoDAO().salvar(dados);

            JOptionPane.showMessageDialog(null,
            "Aluno salvo com sucesso!");
        });

        listar.addActionListener(e -> {
            new TelaListarAluno();
        });

        limpar.addActionListener(e -> {

            for(JComponent campo : campos) {

                if(campo instanceof JTextField) {
                    ((JTextField)campo).setText("");
                }
            }
        });

        sair.addActionListener(e -> dispose());

        add(new JScrollPane(painel));

        setVisible(true);
    }

    class NumeroFilter extends DocumentFilter {

        public void insertString(FilterBypass fb,
        int offset,
        String string,
        AttributeSet attr)
        throws BadLocationException {

            if(string.matches("[0-9]+")) {
                super.insertString(fb, offset, string, attr);
            }
        }

        public void replace(FilterBypass fb,
        int offset,
        int length,
        String text,
        AttributeSet attrs)
        throws BadLocationException {

            if(text.matches("[0-9]+")) {
                super.replace(fb, offset, length, text, attrs);
            }
        }
    }
}
