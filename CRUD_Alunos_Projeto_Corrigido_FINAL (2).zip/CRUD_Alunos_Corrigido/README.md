# CRUD Alunos - Projeto Corrigido

## Como executar

1. Inicie o MySQL.
2. Execute o arquivo:

banco/script.sql

3. Configure usuário e senha do MySQL em:

src/connection/ConnectionFactory.java

4. Execute o projeto Java.

## Correções aplicadas

- Correção de mensagens de erro ao listar alunos.
- Correção de mensagens de erro ao salvar alunos.
- Ajuste da janela de listagem.
- Melhor orientação de configuração do banco.
