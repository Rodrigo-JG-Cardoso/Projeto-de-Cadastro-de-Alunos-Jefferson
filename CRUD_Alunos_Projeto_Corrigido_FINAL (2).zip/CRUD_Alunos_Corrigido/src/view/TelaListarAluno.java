
package view;

import dao.AlunoDAO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class TelaListarAluno extends JFrame {

    JTable tabela = new JTable();
    DefaultTableModel modelo = new DefaultTableModel();

    public TelaListarAluno() {

        setTitle("Lista de Alunos");
        setSize(1000,400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        modelo.addColumn("ID");
        modelo.addColumn("Nome");
        modelo.addColumn("CPF");
        modelo.addColumn("Gênero");
        modelo.addColumn("Cidade");
        modelo.addColumn("Curso");
        modelo.addColumn("Período");
        modelo.addColumn("CEP");

        tabela.setModel(modelo);

        new AlunoDAO().listar(modelo);

        add(new JScrollPane(tabela));

        setVisible(true);
    }
}
