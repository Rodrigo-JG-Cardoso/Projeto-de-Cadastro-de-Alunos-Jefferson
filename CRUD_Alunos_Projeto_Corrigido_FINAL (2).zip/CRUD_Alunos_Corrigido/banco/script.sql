
CREATE DATABASE IF NOT EXISTS cadastro_alunos;
USE cadastro_alunos;

CREATE TABLE aluno (
    id INT AUTO_INCREMENT PRIMARY KEY,
    estuda_etec VARCHAR(5),
    outra_etec VARCHAR(5),
    ja_estudou_etec VARCHAR(5),
    concluiu_medio VARCHAR(5),
    escola VARCHAR(100),

    nome VARCHAR(100),
    nome_social VARCHAR(100),
    cpf VARCHAR(14),
    genero VARCHAR(20),
    data_nascimento VARCHAR(20),
    local_nascimento VARCHAR(100),
    nacionalidade VARCHAR(50),
    pais_origem VARCHAR(50),
    afrodescendente VARCHAR(5),
    escolaridade_publica VARCHAR(5),

    filiacao1 VARCHAR(100),
    filiacao2 VARCHAR(100),
    responsavel VARCHAR(100),
    parentesco VARCHAR(50),

    habilitacao VARCHAR(100),
    serie_modulo VARCHAR(50),
    periodo VARCHAR(30),

    rua VARCHAR(100),
    complemento VARCHAR(100),
    apto VARCHAR(20),
    bloco VARCHAR(20),
    bairro VARCHAR(50),
    cidade VARCHAR(50),
    cep VARCHAR(15)
);
