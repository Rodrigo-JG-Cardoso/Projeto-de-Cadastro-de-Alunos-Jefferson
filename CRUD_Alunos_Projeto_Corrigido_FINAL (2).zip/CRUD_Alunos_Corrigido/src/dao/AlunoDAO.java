
package dao;

import connection.ConnectionFactory;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class AlunoDAO {

    public void salvar(String[] d) {

        String sql =
        "INSERT INTO aluno(" +
        "estuda_etec,outra_etec,ja_estudou_etec,concluiu_medio,escola," +
        "nome,nome_social,cpf,genero,data_nascimento,local_nascimento," +
        "nacionalidade,pais_origem,afrodescendente,escolaridade_publica," +
        "filiacao1,filiacao2,responsavel,parentesco,habilitacao," +
        "serie_modulo,periodo,rua,complemento,apto,bloco,bairro,cidade,cep)" +
        " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        try {

            Connection conn = ConnectionFactory.conectar();
            PreparedStatement stmt = conn.prepareStatement(sql);

            for(int i = 0; i < d.length; i++) {
                stmt.setString(i + 1, d[i]);
            }

            stmt.execute();

            stmt.close();
            conn.close();

        } catch(Exception e) {
            javax.swing.JOptionPane.showMessageDialog(
                null,
                "Erro ao salvar aluno:\n" + e.getMessage()
            );
            e.printStackTrace();
        }
    }

    public void listar(DefaultTableModel modelo) {

        String sql = "SELECT * FROM aluno";

        try {

            Connection conn = ConnectionFactory.conectar();
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {

                modelo.addRow(new Object[] {
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("cpf"),
                    rs.getString("genero"),
                    rs.getString("cidade"),
                    rs.getString("habilitacao"),
                    rs.getString("periodo"),
                    rs.getString("cep")
                });
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch(Exception e) {
            javax.swing.JOptionPane.showMessageDialog(
                null,
                "Erro ao listar alunos:\n" + e.getMessage()
            );
            e.printStackTrace();
        }
    }
}
